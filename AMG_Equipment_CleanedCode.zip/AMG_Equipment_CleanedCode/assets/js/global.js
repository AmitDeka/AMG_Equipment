$(document).ready(function () {
  $(".topBanner_Title").removeClass("d-none");
  $(".topBanner_Title").addClass("animate__animated animate__fadeInDownBig");
});
