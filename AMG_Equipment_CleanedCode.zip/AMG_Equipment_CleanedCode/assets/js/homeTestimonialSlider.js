$(document).ready(function () {
  // Product Page slider
  $(".testimonialHome_containerSlider").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    fade: true,
    infinite: true,
    fade: true,
    swipeToSlide: true,
  });
});
